window.addEventListener('keydown', handler2, false);

var tableInFocus = null; // текущая таблица ввода
var currentCell = null; // текущая ячейка таблицы ввода
var _arrayOfFunctions = []; // массив формул
var currentRow; // текущая строка таблицы ввода

// фунцкция-обработчик нажатия клавиш
function handler2(event) {
	var tbl = document.getElementById(tableInFocus);
	last_row = tbl.rows[tbl.rows.length-1];
	rowCount  = tbl.rows.length;
	switch (event.keyCode) {
		case 37: //стрелка влево
			if (currentCell > 1 && currentRow == rowCount-1) {
				tbl.rows[currentRow].cells[currentCell-1].className = 'ncursor';
				tbl.rows[currentRow].cells[currentCell-2].className = 'rcursor';
				currentCell -= 1;
			}
			if (currentCell > 1 && rowCount > 1 && currentRow < rowCount - 1) {
				tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace("inv");
				tbl.rows[currentRow].cells[currentCell-2].className += ' inv';
				currentCell -= 1;
			}
			break;
		case 39: //стрелка вправо
			if (currentCell == last_row.cells.length) {if (rowCount>1) fillEmptyCell();last_row.insertCell().innerHTML = '_'; }
			if (currentCell < last_row.cells.length && currentRow == rowCount-1) {
				tbl.rows[currentRow].cells[currentCell-1].className = 'ncursor';
				tbl.rows[currentRow].cells[currentCell].className = 'rcursor';
				currentCell += 1;
			}
			if (currentCell < last_row.cells.length && rowCount > 1 && currentRow < rowCount -1) {
				tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace("inv");
				tbl.rows[currentRow].cells[currentCell].className += ' inv';
				currentCell += 1;
			}
			break;
			break;
		case 38: //стрелка вверх 
			if (currentRow == 0  && currentRow == 0) {
				addZeroRow();currentRow = 0;tbl.rows[currentRow+1].cells[currentCell-1].className = tbl.rows[currentRow+1].cells[currentCell-1].className.replace('ncursor');
			} else {tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace('rcursor');
			tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace('inv');
			tbl.rows[currentRow-1].cells[currentCell-1].className += ' inv';currentRow -= 1;}
			break;
		case 40: //стрелка вниз 
			if (currentRow < rowCount) {
				tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace('ncursor');
				tbl.rows[currentRow].cells[currentCell-1].className = tbl.rows[currentRow].cells[currentCell-1].className.replace('inv');
				//tbl.rows[currentRow].cells[currentCell-1].className = 'ncursor';
				if (currentRow+1 == rowCount - 1) tbl.rows[currentRow+1].cells[currentCell-1].className = 'rcursor'; else tbl.rows[currentRow+1].cells[currentCell-1].className += ' inv';
			currentRow += 1;
			}
			break;
		case 81: (last_row.cells[currentCell-1]).innerHTML = 'Q'; break;
		case 87: (last_row.cells[currentCell-1]).innerHTML = 'W'; break;
		case 69: (last_row.cells[currentCell-1]).innerHTML = 'E'; break;
		case 82: (last_row.cells[currentCell-1]).innerHTML = 'R'; break;
		case 84: (last_row.cells[currentCell-1]).innerHTML = 'T'; break;
		case 89: (last_row.cells[currentCell-1]).innerHTML = 'Y'; break;
		case 85: (last_row.cells[currentCell-1]).innerHTML = 'U'; break;
		case 73: (last_row.cells[currentCell-1]).innerHTML = 'I'; break;
		case 79: (last_row.cells[currentCell-1]).innerHTML = 'O'; break;
		case 80: (last_row.cells[currentCell-1]).innerHTML = 'P'; break;
		case 65: (last_row.cells[currentCell-1]).innerHTML = 'A'; break;
		case 83: (last_row.cells[currentCell-1]).innerHTML = 'S'; break;
		case 68: (last_row.cells[currentCell-1]).innerHTML = 'D'; break;
		case 70: (last_row.cells[currentCell-1]).innerHTML = 'F'; break;
		case 71: (last_row.cells[currentCell-1]).innerHTML = 'G'; break;
		case 72: (last_row.cells[currentCell-1]).innerHTML = 'H'; break;
		case 74: (last_row.cells[currentCell-1]).innerHTML = 'J'; break;
		case 75: (last_row.cells[currentCell-1]).innerHTML = 'K'; break;
		case 76: (last_row.cells[currentCell-1]).innerHTML = 'L'; break;
		case 90: (last_row.cells[currentCell-1]).innerHTML = 'Z'; break;
		case 88: (last_row.cells[currentCell-1]).innerHTML = 'X'; break;
		case 67: (last_row.cells[currentCell-1]).innerHTML = 'C'; break;
		case 86: (last_row.cells[currentCell-1]).innerHTML = 'V'; break;
		case 66: (last_row.cells[currentCell-1]).innerHTML = 'B'; break;
		case 78: (last_row.cells[currentCell-1]).innerHTML = 'N'; break;
		case 77: (last_row.cells[currentCell-1]).innerHTML = 'M'; break;

		case 48: if (event.shiftKey) {
					(last_row.cells[currentCell-1]).innerHTML = ')';
				} else {
					(last_row.cells[currentCell-1]).innerHTML = '0';
				}
				break;
		case 49: (last_row.cells[currentCell-1]).innerHTML = '1';break;
		case 57: if (event.shiftKey) (last_row.cells[currentCell-1]).innerHTML = '('; break;

		case 55: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/d.svg" />'; break;
		case 54: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/i.svg" />'; break;
		case 53: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/m.svg" />'; break;
		case 52: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/e.svg" />'; break;
		case 51: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/p.svg" />'; break;
		case 50: (last_row.cells[currentCell-1]).innerHTML = '<img src="pic/s.svg" />'; break;

		case 8: 
			if (currentCell > 1) {
				if (currentCell == last_row.cells.length) break; else
				last_row.deleteCell(currentCell-1);
				currentCell -= 1;
			}
			break;
	}
}

// добавление таблицы для ввода формулы
function addFunction() {
	var form = document.getElementById('form_functions');
	var	tblParent = document.createElement('table');
	var rowParent  = tblParent.insertRow();
	var cellParentL = rowParent.insertCell();
	var cellParentR = rowParent.insertCell();
	cellParentL.style.verticalAlign = 'bottom';
	cellParentL.innerHTML += 'F<sub>' + (_arrayOfFunctions.length+1) + '</sub> = ';
	var	tbl = document.createElement('table');
	tbl.setAttribute('border', '0');
	var lastRow = tbl.insertRow(0);
	var lastCell = lastRow.insertCell();
	lastCell.innerHTML = '_';
	lastCell.className = 'rcursor';
	currentCell = lastRow.cells.length;
	tbl.appendChild(lastRow);
	cellParentR.appendChild(tbl);
	form.appendChild(tblParent);
	tbl.id = 'f' + (_arrayOfFunctions.length+1);
	tableInFocus = tbl.id;
	tbl.onclick = clickOnTable;
	currentRow = 0;
	_arrayOfFunctions.push("");
}

// функция-обработчик клика на таблицу с формулой
function clickOnTable() {
	tableInFocus = tbl.id;
	if (1) {
		var tbl = document.getElementById(tableInFocus);
		lastRow = tbl.rows[tbl.rows.length-1];
		lastRow.cells[currentCell].className = "ncursor";
	}
	tableInFocus = tbl.id;
	var tbl = document.getElementById(tableInFocus);
	lastRow = tbl.rows[tbl.rows.length-1];
	if (1) {
		lastCell = lastRow.insertCell();
		lastCell.className = 'rcursor';
		tableInFocus = this.id;
		currentCell = lastRow.cells.length;
	}
}


// печать символа логической операции на экран
function handler(operation) {
			var tbl = document.getElementById(tableInFocus);
			var lastRow = tbl.rows[tbl.rows.length-1];
			var rowCount = tbl.rows.length;
	switch (operation) {
		case 9: clickInversion(); break;
		case 8: (lastRow.insertCell()).innerHTML = '<img src="pic/c.svg" />'; break;
		case 7: (lastRow.insertCell()).innerHTML = '<img src="pic/d.svg" />'; break;
		case 6: (lastRow.insertCell()).innerHTML = '<img src="pic/i.svg" />'; break;
		case 5: (lastRow.insertCell()).innerHTML = '<img src="pic/m.svg" />'; break;
		case 4: (lastRow.insertCell()).innerHTML = '<img src="pic/e.svg" />'; break;
		case 3: (lastRow.insertCell()).innerHTML = '<img src="pic/p.svg" />'; break;
		case 2: (lastRow.insertCell()).innerHTML = '<img src="pic/s.svg" />'; break;
	}
}

// формирование строки с функциями для POST-запроса
function setArrayOfFunctions() {
	var form = document.getElementById('form_functions');
	form.action = "Bool.php?";
	for (var i=0; i<_arrayOfFunctions.length; i++) {
		var tbl = document.getElementById('f'+(i+1));
		var lastRow = tbl.rows[tbl.rows.length-1];
		var buffer = tbl.cloneNode(true);
		var bufferRow = buffer.rows[buffer.rows.length-1];
		if (tbl.rows.length > 1) {
			for (var k=0; k<tbl.rows.length-1;k++) {
				for (var c=0; c<tbl.rows[k].cells.length;c++) {
					if ( (tbl.rows[k].cells[c].className).indexOf('bord') + 1 ) {
						(lastRow.cells[c]).innerHTML = '9(' + (lastRow.cells[c]).innerHTML;
						(lastRow.cells[c+tbl.rows[k].cells[c].colSpan-1]).innerHTML = (lastRow.cells[c+tbl.rows[k].cells[c].colSpan-1]).innerHTML + ')';
					}
				}
			}
		}
		for (var j=0; j<lastRow.cells.length; j++) {
			var s = (lastRow.cells[j]).innerHTML;
			switch (s) {
				case '<img src="pic/c.svg">': s = '8'; break;
				case '<img src="pic/d.svg">': s = '7'; break;
				case '<img src="pic/i.svg">': s = '6'; break;
				case '<img src="pic/m.svg">': s = '5'; break;
				case '<img src="pic/e.svg">': s = '4'; break;
				case '<img src="pic/p.svg">': s = '3'; break;
				case '<img src="pic/s.svg">': s = '2'; break;
			}
			_arrayOfFunctions[i] += s;
			(lastRow.cells[j]).innerHTML = (bufferRow.cells[j]).innerHTML;
		}
		form.action = form.action + "f" + (i+1) + "=" + _arrayOfFunctions[i];
		if (i < _arrayOfFunctions.length-1) form.action += "&";
	}
}


function fillEmptyCell() {
			var tbl = document.getElementById(tableInFocus);
			var lastRow = tbl.rows[tbl.rows.length-1];
	for (var i=0;i<tbl.rows.length-1;i++) {
		if (tbl.rows[i].cells[currentCell-1].className == 'bord') (tbl.rows[i].cells[currentCell-1]).setAttribute('colspan',(tbl.rows[i].cells[currentCell-1]).getAttribute('colspan')+1);
		(tbl.rows[i].insertCell());
	}
}

// вспомогательная функция: вставка пустой строки в начало и заполнение пустыми ячейками
function addZeroRow() {
	var tbl = document.getElementById(tableInFocus);
	var lastRow = tbl.rows[tbl.rows.length-1];
	var row = tbl.insertRow(0);
	for (var i=0; i<lastRow.cells.length;i++) {
		(row.insertCell()).innerHTML = '';
	}
	currentRow == 0;
	tbl.rows[currentRow+1].cells[currentCell-1].className = tbl.rows[currentRow+1].cells[currentCell-1].className.replace('rcursor');
	tbl.rows[1].cells[currentCell-1].className = tbl.rows[1].cells[currentCell-1].className.replace('inv');
	tbl.rows[0].cells[currentCell-1].className += 'inv';
}

// функция-обработчик нажатия кнопки "Инверсия"
function clickInversion() {
	var tbl = document.getElementById(tableInFocus);
	var row = tbl.rows[currentRow];
	if (currentCell-1 != 0 && (row.cells[currentCell-2].className).indexOf('bord') + 1) {
		row.cells[currentCell-2].colSpan += 1;
	} else
	row.cells[currentCell-1].className += " bord";
row.cells[currentCell-1].innerHTML = '';
}

// вспомогательная функция: поиск закрывающей скобки
function searchParentThesis(somestring) {
	var flag = 0;
	for (var i=0; i<somestring.length; i++) {
		if (somestring[i] === '(') {flag++;} else if (somestring[i] === ')') {flag--;}
		if (flag === 0) return i;
	}
	return 0;
}

// рисование формулы
function drawFormula(formula, id, num) {
	var view = '';
	while (formula) {
		if (formula[0] != '9') {
			switch (formula[0]) {
				case '|': view += '</div>'; break;
				case '8': view += ''; break;
				case '7': view += '<img src="pic/d.svg" />'; break;
				case '6': view += '<img src="pic/i.svg" />'; break;
				case '5': view += '<img src="pic/m.svg" />'; break;
				case '4': view += '<img src="pic/e.svg" />'; break;
				case '3': view += '<img src="pic/p.svg" />'; break;
				case '2': view += '<img src="pic/s.svg" />'; break;
				default: view+= formula[0]; break;
			}
			formula = formula.substr(1, formula.length-1);
		} else {
			formula = formula.substr(1,formula.length-1);
			var str = searchParentThesis(formula);
			formula = formula.substr(1,str-1) + '|' + formula.substr(str+1, formula.length-str-1);
			view += '<div class="top_index">';
		}
	}
	view = 'F<sub>' + num + '</sub> = ' + view + '<br>';
	(document.getElementById(id)).innerHTML += view;
}














