<?php

header("Content-Type: text/html; charset=utf-8");

?>

<html>
	<head>
		<title>Анализ системы булевых функций</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<script type="text/javascript" src="js/custom.js"> </script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	</head>
<body>
	<h1>Веб-приложение "Анализ системы булевых функций"</h1>
	<p>Здесь вы можете проверить систему булевых функций на полноту с помощью теоремы Поста.</p>
	<blockquote><strong>Критерий Поста: </strong><i>Множество F булевых функций полно тогда и только тогда, когда оно не содержится целиком ни в одном из классов Поста.</i></blockquote>
	<p>Нажмите "Добавить функцию", чтобы начать работу.</p>
	<input type="button" class="btn" value="Добавить функцию" onclick="addFunction();" />

	<input type="button" class="btn" value="Инверсия" onclick="handler(9);" title="Инверсия"/>
	<input type="button" value="" class="btn" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/c.svg);" onclick="handler(8);" title="Конъюнкция" />
	<input type="button" value="" class="btn" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/d.svg);" onclick="handler(7);" title="Дизъюнкция" />
	<input type="button" value="" class="btn" onclick="handler(6);" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/i.svg);" title="Импликация" />
	<input type="button" class="btn" value="" onclick="handler(5);" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/m.svg);" title="Сумма по модулю 2" />
	<input type="button" class="btn" value="" onclick="handler(4);" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/e.svg);" title="Эквиваленция" />
	<input type="button" class="btn" value="" onclick="handler(3);" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/p.svg);" title="Стрелка Пирса" />
	<input type="button" class="btn" value="" onclick="handler(2);" style="width: 32px;height:32px;background-repeat: no-repeat;background-position: center center;background-image: url(pic/s.svg);" title="Штрих Шеффера" />

	<form id="form_functions" method="POST" onsubmit="setArrayOfFunctions();"><br>
		<input type="submit" value="Отправить" class="btn" />
	</form>
	<p>По окончании ввода, нажмите "Отправить" для получения результата.</p>
</body>
</html>