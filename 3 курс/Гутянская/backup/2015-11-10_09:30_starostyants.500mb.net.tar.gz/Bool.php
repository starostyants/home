<!DOCTYPE html>
<html>
	<head>
		<title>Анализ системы булевых функций</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<script type="text/javascript" src="js/custom.js"> </script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	</head>
	<body>
<?php

error_reporting(0);

class Bool {

	public $infix;
	public $opn;
	public $truth = array();
	public $c_arg;
	public $vector = '';
	public $polynom = '';
	public $p0_class = '−';
	public $p1_class = '−';
	public $m_class = '+';
	public $s_class = '+';
	public $l_class = '+';
	public $sdnf = '';
	public $sknf = '';
	public $arg = '';
	public $zegalkin = '';

	public function convert($exp) {
		$operands = array('Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','1','0');
		$operators = array('9','8','7','6','5','4','3','2');
		$stack = array();
		for ($i = 0; $i < strlen($exp); $i++) {
			if (in_array(substr($exp, $i, 1),$operands)) { //если токен - операнд
				$exp_o = $exp_o.substr($exp, $i, 1);
			}
			if (in_array(substr($exp, $i, 1),$operators)) {
				while( in_array($stack[count($stack) - 1],$operators) && (substr($exp, $i, 1)<=$stack[count($stack) - 1]) ) {
					$exp_o = $exp_o.$stack[count($stack) - 1];
					array_pop($stack);
				}
				array_push($stack,substr($exp, $i, 1));
			}
			if (substr($exp, $i, 1) == '(') array_push($stack,substr($exp, $i, 1));
			if (substr($exp, $i, 1) == ')') {
				while ($stack[count($stack) - 1] != '(') {
					$exp_o = $exp_o.$stack[count($stack) - 1];
					array_pop($stack);
				}
				array_pop($stack); //удаляем закрывающую скобку
			}
		}
		while ($stack) {
			$exp_o = $exp_o.$stack[count($stack) - 1];
			array_pop($stack);
		}
		return $exp_o;
	}

	public function __construct($exp) {
		$this->infix = $exp;
		$this->opn = $this->convert($exp);
	}

	public function getTable() {
		$operands = array('Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','1','0');
		$str = '';
		for ($i=0; $i < strlen($this->infix); $i++) {
			if (!in_array(substr($this->infix, $i, 1),$this->truth) && in_array(substr($this->infix, $i, 1),$operands) && (substr($this->infix, $i, 1) !='1' && substr($this->infix, $i, 1) != '0' )) //{$t = substr($this->infix, $i, 1);$str = $str.$t;}
				$str = $str.substr($this->infix, $i, 1);
		}


		$str = join(array_unique(str_split($str)));
		for ($i=0;$i<strlen($str);$i++) {
			$str_tmp = $str_tmp.substr($str,$i,1);
			if ($i < strlen($str) -1) $str_tmp = $str_tmp.',';
		}
		$value_tmp = explode(",",$str_tmp);
		$abc = sort($value_tmp);
		for ($i=0;$i<count($value_tmp);$i++) $abc1 = $abc1.$value_tmp[$i];
		
		for ($i=0;$i<strlen($str);$i++) array_push($this->truth,array($abc1[$i]));
		
		$this->c_arg = strlen($str);
		array_push($this->truth,array('F'));
		if ($this->c_arg > 0) {
			for ($i=1;$i<pow(2,$this->c_arg)+1;$i++) {
				$tmp = decbin($i-1);
				while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
				for ($j=0;$j<strlen($tmp);$j++) {
					$this->truth[$j][$i] = $tmp[$j];
				}
			}
		}

	//формирование строки с аргументами	
	for ($i=0; $i<$this->c_arg;$i++) $arg = $arg.$abc1[$i]; 
	$arg = $abc1;
	$this->arg = $arg;
	$stack_o = array();
	for ($i=1;$i<pow(2,$this->c_arg)+1;$i++) {
		$z ='';
		for ($k=0;$k<pow(2,$this->c_arg);$k++) {
			$z = $z.$this->truth[$k][$i];
		}
		for ($j=0; $j < strlen($this->opn); $j++) {
			if (in_array(substr($this->opn, $j, 1),$operands)) {
				if (substr($this->opn, $j, 1) == '0' || substr($this->opn, $j, 1) == '1') array_push( $stack_o, substr($this->opn, $j, 1) ); else
				array_push( $stack_o, $z[position(substr($this->opn, $j, 1),$arg)] );
			} else {
				if (substr($this->opn, $j, 1) == '9') {
					$tmp = $this->inv($stack_o[count($stack_o) - 1]);
					array_pop($stack_o);
					array_push($stack_o,$tmp);
				}
			if (substr($this->opn, $j, 1) == '8') {
				$tmp = $this->con($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '7') {
				$tmp = $this->dis($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '5') {
				$tmp = $this->md2($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '6') {
				$tmp = $this->imp($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '4') {
				$tmp = $this->equ($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '3') {
				$tmp = $this->pie($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
			if (substr($this->opn, $j, 1) == '2') {
				$tmp = $this->she($stack_o[count($stack_o) - 2],$stack_o[count($stack_o) - 1]);
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
		}
		$this->truth[$this->c_arg][$i] = $stack_o[count($stack_o) - 1];
		//print '$stack_o[count($stack_o) - 1]';
	}
	$this->vector.= $stack_o[count($stack_o) - 1];
	array_pop($stack_o);
	}

	$this->setClass();
	$this->setSDNF();
	}


	private function inv($val) {
		if ($val == '0') $t = '1';
		if ($val == '1') $t = '0';
		return $t;
	}
	private function con($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 0;
		if ($value1 == '0' && $value2 == '1') return 0;
		if ($value1 == '1' && $value2 == '0') return 0;
		if ($value1 == '1' && $value2 == '1') return 1;
	}
	private function dis($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 0;
		if ($value1 == '0' && $value2 == '1') return 1;
		if ($value1 == '1' && $value2 == '0') return 1;
		if ($value1 == '1' && $value2 == '1') return 1;
	}
	private function md2($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 0;
		if ($value1 == '0' && $value2 == '1') return 1;
		if ($value1 == '1' && $value2 == '0') return 1;
		if ($value1 == '1' && $value2 == '1') return 0;
	}
	private function imp($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 1;
		if ($value1 == '0' && $value2 == '1') return 1;
		if ($value1 == '1' && $value2 == '0') return 0;
		if ($value1 == '1' && $value2 == '1') return 1;
	}
	private function equ($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 1;
		if ($value1 == '0' && $value2 == '1') return 0;
		if ($value1 == '1' && $value2 == '0') return 0;
		if ($value1 == '1' && $value2 == '1') return 1;
	}
	private function pie($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 1;
		if ($value1 == '0' && $value2 == '1') return 0;
		if ($value1 == '1' && $value2 == '0') return 0;
		if ($value1 == '1' && $value2 == '1') return 0;
	}
	private function she($value1,$value2) {
		if ($value1 == '0' && $value2 == '0') return 1;
		if ($value1 == '0' && $value2 == '1') return 1;
		if ($value1 == '1' && $value2 == '0') return 1;
		if ($value1 == '1' && $value2 == '1') return 0;
	}







	public function setClass() {
		$v_count = strlen($this->vector);
		for ($i=0;$i<$v_count/2;$i++) {
			if ($this->s_class == '+') if ($this->vector[$i] == $this->vector[$v_count-1-$i]) $this->s_class = '−';
		}

		for ($i=1;$i<$v_count;$i++) {
			if ($this->m_class == '+') if (+$this->vector[$i] < +$this->vector[$i-1]) $this->m_class = '−';
		}
		if ($this->vector[0] == '0') $this->p0_class = '+';
		if ($this->vector[$v_count-1] == '1') $this->p1_class = '+';



		$values_array = array();
		for ($i=0;$i<$v_count;$i++) {
			$this->polynom .= '0';
			$tmp = decbin($i);
			while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
			array_push($values_array, $tmp);
		}
		$this->polynom = $this->vector;
		
		$triangle = array($this->polynom);
		for ($i=1;$i<strlen($this->polynom);$i++) {
			$tmp = '';
			for ($j=0;$j<strlen($this->polynom)-$i;$j++) {
				$tmp .= $this->md2($triangle[$i-1][$j],$triangle[$i-1][$j+1]);
			}
			array_push($triangle, $tmp);
			$this->polynom[$i] = $triangle[$i][0];
		}
		for ($i=1;$i<strlen($this->polynom);$i++) {
			if ( getCountOne($values_array[$i])>1 && $this->polynom[$i] == '1' && $this->l_class == '+') $this->l_class = '−';
		}

		for ($i=0;$i<strlen($this->polynom);$i++) {
			if ($this->polynom[$i] == '1') {
				for ($j=0; $j<$this->c_arg; $j++) {
					if ($values_array[$i][$j] == '1') $this->zegalkin .= $this->arg[$j];

				}
				$this->zegalkin .= '5';
			}
		}
		if ($this->zegalkin[strlen($this->zegalkin)-1] == '5') $this->zegalkin = substr($this->zegalkin, 0, -1);
		if ($this->polynom[0] == '1') $this->zegalkin = '1'.$this->zegalkin;
	}

public function getTableTruth() {
	print '<table border=1>';
	for ($i=0;$i<pow(2,$this->c_arg)+1;$i++) {
		print '<tr>';
		for ($j=0;$j<$this->c_arg+1;$j++) {
			echo '<td>'.$this->truth[$j][$i].'</td>';
		}
		print '</tr>';
	}
	print'</table><br>';
}



public function setSDNF() {
	$v_count = strlen($this->vector);
	$values_array = array();
	for ($i=0;$i<$v_count;$i++) {
		$tmp = decbin($i);
		while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
		array_push($values_array, $tmp);
	}
	for ($i=0;$i<$v_count;$i++) {
		if ($this->vector[$i] == "1") {
			$this->sdnf .= "(";
			for ($j=0;$j<$this->c_arg;$j++) {
				if ($values_array[$i][$j] == "1") $this->sdnf .= $this->arg[$j]; else
					$this->sdnf .= "9(".$this->arg[$j].")";
				if ($j != $this->c_arg-1) $this->sdnf .= "8";			
			}
			$this->sdnf .= ")";
		if ($i != $v_count-1) $this->sdnf .= "7";
		}

		if ($this->vector[$i] == "0") {
			$this->sknf .= "(";
			for ($j=0;$j<$this->c_arg;$j++) {
				if ($values_array[$i][$j] == "0") $this->sknf .= $this->arg[$j]; else
					$this->sknf .= "9(".$this->arg[$j].")";
				if ($j != $this->c_arg-1) $this->sknf .= "7";			
			}
			$this->sknf .= ")";
		if ($i != $v_count-1) $this->sknf .= "8";
		}

	}
	if ($this->sdnf[strlen($this->sdnf)-1] == '7') $this->sdnf = substr($this->sdnf, 0, -1);
	if ($this->sknf[strlen($this->sknf)-1] == '8') $this->sknf = substr($this->sknf, 0, -1);
}



}

function getCountOne($val) {
	$count = 0;
	for ($i=0;$i<strlen($val);$i++) {
		if ($val[$i] == '1') $count++;
	}
	return $count;
}



function position($ch,$str) {
	for ($i=0;$i<strlen($str);$i++) {
		if (substr($str,$i,1) == $ch) return $i;
	}
}


$_arrayOfFunctions = array();

$i = 1;
while ($_REQUEST['f'.$i]) {
	array_push($_arrayOfFunctions,new Bool($_REQUEST['f'.$i]));
	$i++;
	//print "Таблица истинности функции F<sub>".($i-1)."</sub>";
	$_arrayOfFunctions[count($_arrayOfFunctions) - 1]->getTable();
}

echo '<div class="korpus">
		<input type="radio" name="tab" checked="checked" id="tab1" />
			<label for="tab1">Полнота системы</label>
		<input type="radio" name="tab" id="tab2" />
			<label for="tab2">Таблицы истинности</label>
		<input type="radio" name="tab" id="tab3" />
			<label for="tab3">СКНФ</label>
		<input type="radio" name="tab" id="tab4" />
			<label for="tab4">СДНФ</label>
		<input type="radio" name="tab" id="tab5" />
			<label for="tab5">Полином Жегалкина</label>
<div>';
$crit = array(0,0,0,0,0);
//print $_arrayOfFunctions[0]->sdnf;

print "Критериальная таблица";
print "<table border=1>";
print "<tr>";
print "<td></td><td>P<sub>0</sub></td><td>P<sub>1</sub></td><td>S</td><td>M</td><td>L</td>";
print "</tr>";
for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print "<tr><td>F<sub>".($i+1)."</sub></td>";
	print "<td>".$_arrayOfFunctions[$i]->p0_class."</td>";if ($_arrayOfFunctions[$i]->p0_class == '−') $crit[0] = 1;
	print "<td>".$_arrayOfFunctions[$i]->p1_class."</td>";if ($_arrayOfFunctions[$i]->p1_class == '−') $crit[1] = 1;
	print "<td>".$_arrayOfFunctions[$i]->s_class."</td>";if ($_arrayOfFunctions[$i]->s_class == '−') $crit[2] = 1;
	print "<td>".$_arrayOfFunctions[$i]->m_class."</td>";if ($_arrayOfFunctions[$i]->m_class == '−') $crit[3] = 1;
	print "<td>".$_arrayOfFunctions[$i]->l_class."</td></tr>";if ($_arrayOfFunctions[$i]->l_class == '−') $crit[4] = 1;
}
print '</table><br>';
print 'Система функций
<div id="area_fun"></div>';


for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print '
		<script>
			drawFormula("'.$_arrayOfFunctions[$i]->infix.'","area_fun",'.($i+1).');
		</script>
	';
}
if (array_sum($crit) > 4) print "является полной."; else print "не является полной."; 

echo '</div> <div>';
for ($i=0; $i<count($_arrayOfFunctions);$i++) {
print "Таблица истинности функции F<sub>".($i+1)."</sub>";
$_arrayOfFunctions[$i]->getTableTruth();
}
echo '</div>

<div id="sknf">	</div>
<div id="sdnf"></div>
<div id="zeg"></div>

</div>';
for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print '
	<script>
		drawFormula("'.$_arrayOfFunctions[$i]->sknf.'","sknf",'.($i+1).');
		drawFormula("'.$_arrayOfFunctions[$i]->sdnf.'","sdnf",'.($i+1).');
		drawFormula("'.$_arrayOfFunctions[$i]->zegalkin.'","zeg",'.($i+1).');
	</script>';
}



?>




	</body>
</html>

