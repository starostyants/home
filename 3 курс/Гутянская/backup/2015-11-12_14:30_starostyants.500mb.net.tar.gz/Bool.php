<?php

class Bool {

	public $infix; // представление логической функции в инфиксной нотации
	private $opn; // представление логической функции в обратной польской нотации
	public $truth = array(); // таблица истинности логической функции
	public $c_arg; // количество аргументов логической функции
	private $vector = ''; // представление в виде вектора
	private $polynom = ''; // коэффициенты полинома Жегалкина
	public $p0_class = '−'; // флаг принадлежности классу функций, сохраняющих константу 0
	public $p1_class = '−'; // сохраняющих константу 1
	public $m_class = '+'; // монотонных 
	public $s_class = '+'; // самодвойственных
	public $l_class = '+'; // линейных
	public $sdnf = ''; // СДНФ в инфиксной нотации
	public $sknf = ''; // СКНФ в инфиксной нотации
	private $arg = ''; // строка с аргументами логической функции
	public $zegalkin = ''; // полином Жегалкина в инфиксной нотации

// преобразование из инфиксной нотации в обратную польскую
// алгоритмом сортировочной станции
	private function convert($exp) {
		$operands = array('Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','1','0');
		$operators = array('9','8','7','6','5','4','3','2');
		$stack = array();
		for ($i = 0; $i < strlen($exp); $i++) {
			if (in_array(substr($exp, $i, 1),$operands)) { //если токен - операнд
				$exp_o = $exp_o.substr($exp, $i, 1);
			}
			if (in_array(substr($exp, $i, 1),$operators)) {
				while( in_array($stack[count($stack) - 1],$operators) && (substr($exp, $i, 1)<=$stack[count($stack) - 1]) ) {
					$exp_o = $exp_o.$stack[count($stack) - 1];
					array_pop($stack);
				}
				array_push($stack,substr($exp, $i, 1));
			}
			if (substr($exp, $i, 1) == '(') array_push($stack,substr($exp, $i, 1));
			if (substr($exp, $i, 1) == ')') {
				while ($stack[count($stack) - 1] != '(') {
					$exp_o = $exp_o.$stack[count($stack) - 1];
					array_pop($stack);
				}
				array_pop($stack); //удаляем закрывающую скобку
			}
		}
		while ($stack) {
			$exp_o = $exp_o.$stack[count($stack) - 1];
			array_pop($stack);
		}
		return $exp_o;
	}

	public function __construct($exp) {
		$this->infix = $exp; 
		$this->opn = $this->convert($exp);
		$this->init();
	}


	public function init() {
		$operands = array('Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','1','0');
		$string_operands = '';
		for ($i=0; $i < strlen($this->infix); $i++) {
			if (in_array(substr($this->infix, $i, 1),$operands) && (substr($this->infix, $i, 1) !='1' && substr($this->infix, $i, 1) != '0' ))
				$string_operands = $string_operands.substr($this->infix, $i, 1);
		}
		$string_operands = join(array_unique(str_split($string_operands)));
		for ($i=0;$i<strlen($string_operands);$i++) {
			$str_tmp = $str_tmp.substr($string_operands,$i,1);
			if ($i < strlen($string_operands) -1) $str_tmp = $str_tmp.',';
		}
		$value_tmp = explode(",",$str_tmp);
		sort($value_tmp);
		for ($i=0;$i<count($value_tmp);$i++) $this->arg .= $value_tmp[$i];

		for ($i=0;$i<strlen($string_operands);$i++) array_push($this->truth,array($this->arg[$i]));
		$this->c_arg = strlen($string_operands);
		array_push($this->truth,array('F'));
		if ($this->c_arg > 0) {
			for ($i=1;$i<pow(2,$this->c_arg)+1;$i++) {
				$tmp = decbin($i-1);
				while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
				for ($j=0;$j<strlen($tmp);$j++) {
					$this->truth[$j][$i] = $tmp[$j];
				}
			}
		}

	$stack_o = array();

	if ($this->c_arg == 0) {
		for ($j=0; $j < strlen($this->opn); $j++) {
			if (in_array(substr($this->opn, $j, 1),$operands)) {
				if (substr($this->opn, $j, 1) == '0' || substr($this->opn, $j, 1) == '1') array_push( $stack_o, substr($this->opn, $j, 1) );
			} else {
				switch (substr($this->opn, $j, 1)) {
					case '9': $tmp = +(!$stack_o[count($stack_o) - 1]); break;
					case '8': $tmp = +($stack_o[count($stack_o) - 2] && $stack_o[count($stack_o) - 1]); break;
					case '7': $tmp = +($stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1]); break;
					case '6': $tmp = +(!$stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1]); break;
					case '5': $tmp = +((!$stack_o[count($stack_o) - 2] || !$stack_o[count($stack_o) - 1]) && +($stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1])); break;
					case '4': $tmp = +(+(!$stack_o[count($stack_o) - 2] && !$stack_o[count($stack_o) - 1]) || +($stack_o[count($stack_o) - 2] && $stack_o[count($stack_o) - 1])); break;
					case '3': $tmp = +(!$stack_o[count($stack_o) - 2] && !$stack_o[count($stack_o) - 1]); break;
					case '2': $tmp = +(!$stack_o[count($stack_o) - 2] || !$stack_o[count($stack_o) - 1]); break;
				}
				array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
			}
		$this->truth[0][1] = $stack_o[count($stack_o) - 1];
	}


	 } else // если в функции есть аргументы
	for ($i=1;$i<pow(2,$this->c_arg)+1;$i++) {
		$z =''; // текущий набор
		for ($k=0;$k<pow(2,$this->c_arg);$k++) {
			$z = $z.$this->truth[$k][$i];
		}
	
		for ($j=0; $j < strlen($this->opn); $j++) {
			if (in_array(substr($this->opn, $j, 1),$operands)) {
				if (substr($this->opn, $j, 1) == '0' || substr($this->opn, $j, 1) == '1') array_push( $stack_o, substr($this->opn, $j, 1) ); else
				array_push( $stack_o, $z[position(substr($this->opn, $j, 1),$this->arg)] );
				
			} else {
				switch (substr($this->opn, $j, 1)) {
					case '9': $tmp = +(!$stack_o[count($stack_o) - 1]); break;
					case '8': $tmp = +($stack_o[count($stack_o) - 2] && $stack_o[count($stack_o) - 1]); break;
					case '7': $tmp = +($stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1]); break;
					case '6': $tmp = +(!$stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1]); break;
					case '5': $tmp = +((!$stack_o[count($stack_o) - 2] || !$stack_o[count($stack_o) - 1]) && +($stack_o[count($stack_o) - 2] || $stack_o[count($stack_o) - 1])); break;
					case '4': $tmp = +(+(!$stack_o[count($stack_o) - 2] && !$stack_o[count($stack_o) - 1]) || +($stack_o[count($stack_o) - 2] && $stack_o[count($stack_o) - 1])); break;
					case '3': $tmp = +(!$stack_o[count($stack_o) - 2] && !$stack_o[count($stack_o) - 1]); break;
					case '2': $tmp = +(!$stack_o[count($stack_o) - 2] || !$stack_o[count($stack_o) - 1]); break;
				}
				if (substr($this->opn, $j, 1) != '9') array_pop($stack_o);
				array_pop($stack_o);
				array_push($stack_o,$tmp);
		}
		$this->truth[$this->c_arg][$i] = $stack_o[count($stack_o) - 1];

	}
	$this->vector.= $stack_o[count($stack_o) - 1];
	array_pop($stack_o);

	}

	$this->setClass();
	$this->setForms();
	}



	private function setClass() {
		$v_count = strlen($this->vector);
		for ($i=0;$i<$v_count/2;$i++) {
			if ($this->s_class == '+') if ($this->vector[$i] == $this->vector[$v_count-1-$i]) $this->s_class = '−';
		}

		for ($i=1;$i<$v_count;$i++) {
			if ($this->m_class == '+') if (+$this->vector[$i] < +$this->vector[$i-1]) $this->m_class = '−';
		}
		if ($this->vector[0] == '0') $this->p0_class = '+';
		if ($this->vector[$v_count-1] == '1') $this->p1_class = '+';



		$values_array = array();
		for ($i=0;$i<$v_count;$i++) {
			$this->polynom .= '0';
			$tmp = decbin($i);
			while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
			array_push($values_array, $tmp);
		}
		$this->polynom = $this->vector;
		
		$triangle = array($this->polynom);
		for ($i=1;$i<strlen($this->polynom);$i++) {
			$tmp = '';
			for ($j=0;$j<strlen($this->polynom)-$i;$j++) {
				$tmp .= +(+(!$triangle[$i-1][$j] || !$triangle[$i-1][$j+1]) && +($triangle[$i-1][$j] || $triangle[$i-1][$j+1]));
			}
			array_push($triangle, $tmp);
			$this->polynom[$i] = $triangle[$i][0];
		}
		for ($i=1;$i<strlen($this->polynom);$i++) {
			if ( getCountOne($values_array[$i])>1 && $this->polynom[$i] == '1' && $this->l_class == '+') $this->l_class = '−';
		}

		for ($i=0;$i<strlen($this->polynom);$i++) {
			if ($this->polynom[$i] == '1') {
				for ($j=0; $j<$this->c_arg; $j++) {
					if ($values_array[$i][$j] == '1') $this->zegalkin .= $this->arg[$j];

				}
				$this->zegalkin .= '5';
			}
		}
		if ($this->zegalkin[strlen($this->zegalkin)-1] == '5') $this->zegalkin = substr($this->zegalkin, 0, -1);
		if ($this->polynom[0] == '1') $this->zegalkin = '1'.$this->zegalkin;
	}

public function getTruthTable() {
	print '<table border=1>';
	for ($i=0;$i<pow(2,$this->c_arg)+1;$i++) {
		print '<tr>';
		for ($j=0;$j<$this->c_arg+1;$j++) {
			echo '<td>'.$this->truth[$j][$i].'</td>';
		}
		print '</tr>';
	}
	print'</table><br>';
}



	private function setForms() {
$v_count = strlen($this->vector);
	$values_array = array();
	for ($i=0;$i<$v_count;$i++) {
		$tmp = decbin($i);
		while (strlen($tmp) != $this->c_arg) $tmp = '0'.$tmp;
		array_push($values_array, $tmp);
	}
	for ($i=0;$i<$v_count;$i++) {
		if ($this->vector[$i] == "1") {
			$this->sdnf .= "(";
			for ($j=0;$j<$this->c_arg;$j++) {
				if ($values_array[$i][$j] == "1") $this->sdnf .= $this->arg[$j]; else
					$this->sdnf .= "9(".$this->arg[$j].")";
				if ($j != $this->c_arg-1) $this->sdnf .= "8";			
			}
			$this->sdnf .= ")";
		if ($i != $v_count-1) $this->sdnf .= "7";
		}

		if ($this->vector[$i] == "0") {
			$this->sknf .= "(";
			for ($j=0;$j<$this->c_arg;$j++) {
				if ($values_array[$i][$j] == "0") $this->sknf .= $this->arg[$j]; else
					$this->sknf .= "9(".$this->arg[$j].")";
				if ($j != $this->c_arg-1) $this->sknf .= "7";			
			}
			$this->sknf .= ")";
		if ($i != $v_count-1) $this->sknf .= "8";
		}

	}
	if ($this->sdnf[strlen($this->sdnf)-1] == '7') $this->sdnf = substr($this->sdnf, 0, -1);
	if ($this->sknf[strlen($this->sknf)-1] == '8') $this->sknf = substr($this->sknf, 0, -1);
}



}