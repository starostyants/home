<!DOCTYPE html>
<html>
	<head>
		<title>Анализ системы булевых функций</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<script type="text/javascript" src="js/custom.js"> </script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	</head>
	<body>
<?php

error_reporting(0);

require_once('Bool.php');


function getCountOne($val) {
	$count = 0;
	for ($i=0;$i<strlen($val);$i++) {
		if ($val[$i] == '1') $count++;
	}
	return $count;
}



function position($ch,$str) {
	for ($i=0;$i<strlen($str);$i++) {
		if (substr($str,$i,1) == $ch) return $i;
	}
}


$_arrayOfFunctions = array();
$crit = array(0,0,0,0,0);

$i = 1;
while ($_REQUEST['f'.$i]) {
	array_push($_arrayOfFunctions,new Bool($_REQUEST['f'.$i]));
	$i++;
}

?>

<div class="korpus">
	<input type="radio" name="tab" checked="checked" id="tab1" />
	<label for="tab1">Полнота системы</label>
	<input type="radio" name="tab" id="tab2" />
	<label for="tab2">Таблицы истинности</label>
	<input type="radio" name="tab" id="tab3" />
	<label for="tab3">СКНФ</label>
	<input type="radio" name="tab" id="tab4" />
	<label for="tab4">СДНФ</label>
	<input type="radio" name="tab" id="tab5" />
	<label for="tab5">Полином Жегалкина</label>
<div>



Критериальная таблица
<table border=1>
	<tr>
		<td></td>
		<td>P<sub>0</sub></td>
		<td>P<sub>1</sub></td>
		<td>S</td><td>M</td>
		<td>L</td>
	</tr>

<?php

for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print "<tr><td>F<sub>".($i+1)."</sub></td>";
	print "<td>".$_arrayOfFunctions[$i]->p0_class."</td>";if ($_arrayOfFunctions[$i]->p0_class == '−') $crit[0] = 1;
	print "<td>".$_arrayOfFunctions[$i]->p1_class."</td>";if ($_arrayOfFunctions[$i]->p1_class == '−') $crit[1] = 1;
	print "<td>".$_arrayOfFunctions[$i]->s_class."</td>";if ($_arrayOfFunctions[$i]->s_class == '−') $crit[2] = 1;
	print "<td>".$_arrayOfFunctions[$i]->m_class."</td>";if ($_arrayOfFunctions[$i]->m_class == '−') $crit[3] = 1;
	print "<td>".$_arrayOfFunctions[$i]->l_class."</td></tr>";if ($_arrayOfFunctions[$i]->l_class == '−') $crit[4] = 1;
}
print '</table><br>';
print 'Система функций
<div id="area_fun"></div>';


for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print '
		<script>
			drawFormula("'.$_arrayOfFunctions[$i]->infix.'","area_fun",'.($i+1).');
		</script>
	';
}
if (array_sum($crit) > 4) print "является полной."; else print "не является полной."; 

echo '</div> <div>';
for ($i=0; $i<count($_arrayOfFunctions);$i++) {
print "Таблица истинности функции F<sub>".($i+1)."</sub>";
$_arrayOfFunctions[$i]->getTruthTable();
}
echo '</div>

<div id="sknf">	</div>
<div id="sdnf"></div>
<div id="zeg"></div>

</div>';
for ($i=0; $i<count($_arrayOfFunctions);$i++) {
	print '
	<script>
		drawFormula("'.$_arrayOfFunctions[$i]->sknf.'","sknf",'.($i+1).');
	</script>'; if ($_arrayOfFunctions[$i]->c_arg === 0 && $_arrayOfFunctions[$i]->truth[0][1] == '0') {print 'Для константы 0 не существует СДНФ.';} else {
	print '<script>drawFormula("'.$_arrayOfFunctions[$i]->sdnf.'","sdnf",'.($i+1).');</script>';}
	print '<script>
		drawFormula("'.$_arrayOfFunctions[$i]->zegalkin.'","zeg",'.($i+1).');
	</script>';
}



?>




	</body>
</html>

